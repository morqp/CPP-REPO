Thank you for downloading!

Run "fightergame.exe" to play.

If there's any issues, please contact:
mariacosneanu.dcms.site